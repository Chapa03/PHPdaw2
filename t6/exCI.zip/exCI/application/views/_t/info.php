<div class="container">
	<h3 class="alert alert-<?=$severity?>"><?=$msg?></h3>
	<form action="<?=$uri?>">
		<button type="submit" class="btn btn-secondary" >Volver</button>
	</form>
</div>
	